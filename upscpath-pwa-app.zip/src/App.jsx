import UPSCPathClone from './UPSCPathClone.jsx'

export default function App() {
  return <UPSCPathClone />
}
