import React, { useEffect, useState, useMemo } from "react";

const SHEET_ID = "1PbhlfUvzAGxJLkS8N4agphLtBkoLCbb6Mi5raKVd2ho";
const GID = "341448003";
const CSV_URL = `https://docs.google.com/spreadsheets/d/${SHEET_ID}/export?format=csv&gid=${GID}`;

function parseCSV(text) {
  const lines = text.split(/\r?\n/).filter(Boolean);
  if (lines.length === 0) return [];
  const headers = lines[0].split(",").map(h => h.trim());
  const rows = lines.slice(1).map(line => {
    const cols = line.split(",");
    const obj = {};
    headers.forEach((h, i) => {
      obj[h] = (cols[i] || "").trim();
    });
    return obj;
  });
  return rows;
}

export default function UPSCPathClone() {
  const [items, setItems] = useState([]);
  const [query, setQuery] = useState("");
  const [tagFilter, setTagFilter] = useState("All");
  const [sortBy, setSortBy] = useState("relevance");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(12);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function load() {
      setLoading(true);
      setError(null);
      try {
        const res = await fetch(CSV_URL);
        if (!res.ok) throw new Error(`HTTP ${res.status}`);
        const text = await res.text();
        const parsed = parseCSV(text);
        const normalized = parsed.map((r, idx) => ({
          id: r.id || r.ID || `row-${idx}`,
          title: r.title || r.Title || r.name || r.Name || "Untitled",
          description: r.description || r.Description || r.summary || r.Summary || "",
          tags: (r.tags || r.Tags || r.category || r.Category || "").split(/[,;]\s*/).filter(Boolean),
          url: r.url || r.URL || r.link || r.Link || "",
          source: r.source || r.Source || "",
          extra: r,
        }));
        setItems(normalized);
      } catch (e) {
        setError(e.message);
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  const allTags = useMemo(() => {
    const s = new Set();
    items.forEach(it => (it.tags || []).forEach(t => s.add(t)));
    return ["All", ...Array.from(s).sort()];
  }, [items]);

  const filtered = useMemo(() => {
    let out = items.slice();
    if (tagFilter !== "All") {
      out = out.filter(it => (it.tags || []).includes(tagFilter));
    }
    if (query.trim()) {
      const q = query.toLowerCase();
      out = out.filter(it => ((it.title||"") + " " + (it.description||"") + " " + ((it.tags||[]).join(" "))).toLowerCase().includes(q));
    }
    if (sortBy === "title") out.sort((a, b) => a.title.localeCompare(b.title));
    return out;
  }, [items, query, tagFilter, sortBy]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / pageSize));
  useEffect(() => {
    if (page > totalPages) setPage(1);
  }, [totalPages]);

  const pageItems = useMemo(() => {
    const start = (page - 1) * pageSize;
    return filtered.slice(start, start + pageSize);
  }, [filtered, page, pageSize]);

  return (
    <div className="p-6 max-w-6xl mx-auto">
      <header className="mb-6">
        <h1 className="text-3xl font-extrabold mb-1">UPSCPath — PWA Clone</h1>
        <p className="text-sm text-gray-600">Data pulled from your Google Sheet. Installable as an app.</p>
      </header>

      <div className="flex gap-4 mb-6 flex-wrap">
        <input
          value={query}
          onChange={e => { setQuery(e.target.value); setPage(1); }}
          placeholder="Search..."
          className="flex-1 min-w-[220px] border rounded-lg p-2 shadow-sm"
        />
        <select value={tagFilter} onChange={e => { setTagFilter(e.target.value); setPage(1); }} className="border rounded-lg p-2">
          {allTags.map(t => <option key={t} value={t}>{t}</option>)}
        </select>
        <select value={sortBy} onChange={e => setSortBy(e.target.value)} className="border rounded-lg p-2">
          <option value="relevance">Relevance</option>
          <option value="title">Title</option>
        </select>
      </div>

      {loading && <div>Loading sheet...</div>}
      {error && <div style={{color:"red"}}>Error: {error}</div>}

      <main>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {pageItems.map(item => (
            <article key={item.id} className="bg-white p-4 rounded-2xl shadow-md">
              <h2 className="font-semibold text-lg">{item.title}</h2>
              <p className="text-sm text-gray-600 truncate my-2">{item.description}</p>
              <div className="flex flex-wrap gap-2 my-2">
                {(item.tags||[]).map(t => <span key={t} className="text-xs px-2 py-1 rounded-full border">{t}</span>)}
              </div>
              {item.url && <a href={item.url} target="_blank" rel="noreferrer" className="text-blue-600 underline">Open</a>}
            </article>
          ))}
        </div>
      </main>
    </div>
  );
}
